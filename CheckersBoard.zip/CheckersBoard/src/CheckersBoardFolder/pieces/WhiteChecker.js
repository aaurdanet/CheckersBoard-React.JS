import whiteChecker from '../../assets/white-checker.svg'

function WhiteChecker(props) {
    return (
        <img src={whiteChecker} alt={'A white checker.'} className={'piece'} />
    )
}

export default WhiteChecker